<script setup name="Footer">
import Footer from "./Footer/Footer.vue";
</script>

<template>
  <footer>
    <Footer />
  </footer>
</template>

<style scoped>
footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
}
</style>
