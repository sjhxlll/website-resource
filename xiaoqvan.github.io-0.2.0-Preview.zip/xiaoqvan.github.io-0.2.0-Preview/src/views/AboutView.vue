<!-- 关于 -->
<script setup name="AboutView">

</script>


<template>
  <div>关于</div>
</template>


<style scoped></style>
