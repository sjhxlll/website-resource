<template>
    <div>
        <h1>404</h1>
        <h2>你在访问一个不存在的页面</h2>
    </div>
</template>
<script setup lang="ts" name="404">

</script>