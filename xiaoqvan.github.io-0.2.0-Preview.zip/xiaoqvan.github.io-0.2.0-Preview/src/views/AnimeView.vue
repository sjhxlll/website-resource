<script setup name="AnimeView">
import Anime from '@/components/Anime.vue'
import Footer from "@/components/Footer_bar.vue";
import background from "@/components/formerbg.vue"
</script>

<template>
  <background />
  <Anime />
  <Footer />
</template>
