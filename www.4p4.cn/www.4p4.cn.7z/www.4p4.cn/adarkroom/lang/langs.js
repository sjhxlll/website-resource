var langs = {
 'cn':'简体中文',
  'en':'English',
}
